CUPS Readme
6.9.2016

CUPS converts UPS patches to EA files.

How to use:
1. Drag a UPS patch onto CUPS.exe
2. Select the clean rom that the patch is intended for.
3. CUPS will create a .event file that you can #include or assemble directly with Event Assembler
